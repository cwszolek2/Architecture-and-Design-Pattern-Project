//**STRATEGY PATTERN**
//ACTION
// This is an inherited function by children, created by part of the abstract factory pattern.
//Wrong Pin message sent to user.
public class WrongPinMsg {
    public void wrongPinMsg(){
        System.out.println("Shouldn't see this");
    }
}

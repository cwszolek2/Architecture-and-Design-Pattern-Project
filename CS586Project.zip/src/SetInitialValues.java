//**STRATEGY PATTERN**
//ACTION
// This is an inherited function by children, created by part of the abstract factory pattern.
//Sets G or L and total to 0.
public class SetInitialValues {
    public void setInitialValues(DataStore ds){
        System.out.println("Shouldn't see this");
    }
}


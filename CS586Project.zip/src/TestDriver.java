//Sorry, completely ran out of time for developing the test driver.  would have been pretty standard
//Equivalent Partitioning style testing.
//There's not much error checking, sadly something that was cut due to time constraints.
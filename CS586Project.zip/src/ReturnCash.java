//**STRATEGY PATTERN**
//ACTION
// This is an inherited function by children, created by part of the abstract factory pattern.
//Returns inserted cash to user
public class ReturnCash {
    public void returnCash(DataStore ds){
        System.out.println("Shouldn't see this");
    }
}


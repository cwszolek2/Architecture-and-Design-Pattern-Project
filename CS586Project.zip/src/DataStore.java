//***STATE PATTERN***

//Parent class to be inherited by children.
//Empty class
public abstract class DataStore{
    //empty class to hold data.
}
//**STRATEGY PATTERN**
//ACTION
// This is an inherited function by children, created by part of the abstract factory pattern.
//Sets price to a certain amount.
public class SetPrice {
    public void setPrice(int g, DataStore ds){
        System.out.println("Shouldn't see this");
    }
}

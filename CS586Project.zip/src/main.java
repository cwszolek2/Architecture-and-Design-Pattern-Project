<?xml version="1.0" encoding="ISO-8859-1"?>
<jsmoothproject>
<JVMSearchPath>registry</JVMSearchPath>
<JVMSearchPath>javahome</JVMSearchPath>
<JVMSearchPath>jrepath</JVMSearchPath>
<JVMSearchPath>jdkpath</JVMSearchPath>
<JVMSearchPath>exepath</JVMSearchPath>
<JVMSearchPath>jview</JVMSearchPath>
<arguments></arguments>
<classPath>main.java</classPath>
<classPath>..\class</classPath>
<classPath>.</classPath>
<currentDirectory>.</currentDirectory>
<embeddedJar>true</embeddedJar>
<executableName>project.exe</executableName>
<initialMemoryHeap>-1</initialMemoryHeap>
<jarLocation>..\JarFile.jar</jarLocation>
<mainClassName>main</mainClassName>
<maximumMemoryHeap>-1</maximumMemoryHeap>
<maximumVersion></maximumVersion>
<minimumVersion></minimumVersion>
<skeletonName>Console Wrapper</skeletonName>
<skeletonProperties>
<key>Message</key>
<value>This program needs Java to run.
Please download it at http://www.java.com</value>
</skeletonProperties>
<skeletonProperties>
<key>PressKey</key>
<value>0</value>
</skeletonProperties>
<skeletonProperties>
<key>Debug</key>
<value>0</value>
</skeletonProperties>
</jsmoothproject>

README
CS 586 Part 2 Project
Chris Wszolek
A20434973
Compiled and tested in Java 12.0.1
To run:
Double click project.exe.

**If this does not work (I have not extensively tested it), .jar file is provided.  To run, ensure java is in path, and type:
java -jar JarFile.jar
If recompilation is required (big sorry if this happens), all of source files are located in src folder.  Class files also located in class folder.